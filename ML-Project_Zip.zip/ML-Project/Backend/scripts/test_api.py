"""
Simple API smoke tests (Postman alternative / companion).
Run while the Flask server is up:

    python scripts/test_api.py
"""

import json
import sys

import requests

BASE_URL = "http://127.0.0.1:5000/api"

# Valid applicant sample (matches German Credit categories used in training)
VALID_APPLICANT = {
    "status_account": "< 0 DM",
    "Loan_duration": 12,
    "credit_history": "existing credits paid back duly till now",
    "Loan_purpose": "radio/television",
    "credit_amount": 2500,
    "status_savings": "< 100 DM",
    "employment_since": "1 to < 4 years",
    "payment_to_income_ratio": 2,
    "status_and_sex": "male : single",
    "secondary_obligor": "none",
    "residence_since": 2,
    "collateral": "none",
    "age": 35,
    "other_installment_plans": "none",
    "Housing_ownership": "own",
    "n_credits": 1,
    "job": "skilled employee/ official",
    "n_guarantors": 1,
    "telephone": "none",
    "work_eligibility_status": "yes",
    "created_by": "admin",
}

INVALID_APPLICANT = {
    "status_account": "invalid-category",
    "Loan_duration": -5,
    "age": 0,
}


def pretty(title, response):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)
    print(f"Status: {response.status_code}")
    try:
        print(json.dumps(response.json(), indent=2))
    except Exception:
        print(response.text)
    return response


def main():
    failures = 0

    # 1. Health
    r = pretty("GET /api/health", requests.get(f"{BASE_URL}/health", timeout=10))
    if r.status_code != 200:
        failures += 1

    # 2. Login – valid
    r = pretty(
        "POST /api/login (valid)",
        requests.post(
            f"{BASE_URL}/login",
            json={"username": "admin", "password": "admin123"},
            timeout=10,
        ),
    )
    if r.status_code != 200:
        failures += 1

    # 3. Login – invalid
    r = pretty(
        "POST /api/login (invalid)",
        requests.post(
            f"{BASE_URL}/login",
            json={"username": "admin", "password": "wrong"},
            timeout=10,
        ),
    )
    if r.status_code != 401:
        failures += 1

    # 4. Predict – valid
    r = pretty(
        "POST /api/predict (valid)",
        requests.post(f"{BASE_URL}/predict", json=VALID_APPLICANT, timeout=30),
    )
    prediction_id = None
    if r.status_code == 200:
        prediction_id = r.json().get("data", {}).get("record", {}).get("id")
    else:
        failures += 1

    # 5. Predict – invalid
    r = pretty(
        "POST /api/predict (invalid)",
        requests.post(f"{BASE_URL}/predict", json=INVALID_APPLICANT, timeout=10),
    )
    if r.status_code != 400:
        failures += 1

    # 6. History list
    r = pretty("GET /api/history", requests.get(f"{BASE_URL}/history", timeout=10))
    if r.status_code != 200:
        failures += 1

    # 7. History by id
    if prediction_id:
        r = pretty(
            f"GET /api/history/{prediction_id}",
            requests.get(f"{BASE_URL}/history/{prediction_id}", timeout=10),
        )
        if r.status_code != 200:
            failures += 1

        # 8. Delete
        r = pretty(
            f"DELETE /api/history/{prediction_id}",
            requests.delete(f"{BASE_URL}/history/{prediction_id}", timeout=10),
        )
        if r.status_code != 200:
            failures += 1

        # 9. Confirm deleted -> 404
        r = pretty(
            f"GET /api/history/{prediction_id} (after delete)",
            requests.get(f"{BASE_URL}/history/{prediction_id}", timeout=10),
        )
        if r.status_code != 404:
            failures += 1
    else:
        print("\nSkipping history detail/delete tests (no prediction id).")
        failures += 1

    print("\n" + "=" * 70)
    if failures == 0:
        print("ALL API TESTS PASSED")
        return 0
    print(f"TESTS FINISHED WITH {failures} FAILURE(S)")
    return 1


if __name__ == "__main__":
    sys.exit(main())
