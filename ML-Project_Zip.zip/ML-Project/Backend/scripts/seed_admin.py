"""
Seed a default loan-officer user for local development / viva demo.

Usage (from Backend folder):
    python scripts/seed_admin.py

Default credentials:
    username: admin
    password: admin123
"""

import sys
from pathlib import Path

BACKEND_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_ROOT))

from flask import Flask
from config import Config
from database import init_db, close_db
from models import UserModel
from services import AuthService


def seed_admin():
    app = Flask(__name__)
    app.config.from_object(Config)

    with app.app_context():
        init_db(app)

        username = "admin"
        password = "admin123"
        role = "admin"

        existing = UserModel.find_by_username(username)
        if existing:
            print(f"User '{username}' already exists. Skipping seed.")
            print(f"Public profile: {UserModel.to_public_dict(existing)}")
            return

        user = AuthService.register_user(username, password, role=role)
        print("Admin user created successfully.")
        print(f"Username : {username}")
        print(f"Password : {password}")
        print(f"User     : {user}")


if __name__ == "__main__":
    try:
        seed_admin()
    finally:
        close_db()
