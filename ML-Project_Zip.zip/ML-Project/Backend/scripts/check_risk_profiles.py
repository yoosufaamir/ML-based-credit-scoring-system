import joblib
import pandas as pd
from pathlib import Path

root = Path(r"C:\Users\NEXEN Technologies\Desktop\ML-Project")
model = joblib.load(root / "Saved models" / "Random_forest.pkl")
pre = joblib.load(root / "Saved models" / "preprocessor.pkl")
AMT = "credit_amount'(000)"


def run(name, d):
    X = pre.transform(pd.DataFrame([d]))
    pred = int(model.predict(X)[0])
    p = model.predict_proba(X)[0]
    label = "Good" if pred == 1 else "Bad"
    print(f"{name}: {label}  conf={p[pred]:.2f}  (bad={p[0]:.2f}, good={p[1]:.2f})")


safe = {
    "status_account": ">= 200 DM",
    "Loan_duration": 12,
    "credit_history": "all credits at this bank paid back duly",
    "Loan_purpose": "radio/television",
    AMT: 1500,
    "status_savings": ">= 1000 DM",
    "employment_since": ">= 7 years",
    "payment_to_income_ratio": 2,
    "status_and_sex": "male : single",
    "secondary_obligor": "none",
    "residence_since": 4,
    "collateral": "real estate",
    "age": 45,
    "other_installment_plans": "none",
    "Housing_ownership": "own",
    "n_credits": 1,
    "job": "skilled employee/ official",
    "n_guarantors": 1,
    "telephone": "yes, registered under the customers name",
    "work_eligibility_status": "yes",
}

risky = {
    "status_account": "< 0 DM",
    "Loan_duration": 48,
    "credit_history": "critical account/ other credits existing (not at this bank)",
    "Loan_purpose": "education",
    AMT: 12000,
    "status_savings": "< 100 DM",
    "employment_since": "unemployed",
    "payment_to_income_ratio": 4,
    "status_and_sex": "female : divorced/separated/married",
    "secondary_obligor": "none",
    "residence_since": 1,
    "collateral": "none",
    "age": 22,
    "other_installment_plans": "bank",
    "Housing_ownership": "rent",
    "n_credits": 4,
    "job": "unemployed/ unskilled - non-resident",
    "n_guarantors": 1,
    "telephone": "none",
    "work_eligibility_status": "no",
}

run("SAFE profile", safe)
run("RISKY profile", risky)
print("classes", model.classes_)
