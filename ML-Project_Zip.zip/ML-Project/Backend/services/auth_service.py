"""
Authentication service.
Handles login logic using hashed passwords stored in MongoDB.
"""

from models import UserModel
from utils.password import check_password, hash_password


class AuthService:
    """Business logic for user authentication."""

    @staticmethod
    def login(username, password):
        """
        Authenticate a user.

        Returns
        -------
        dict
            Public user profile on success.

        Raises
        ------
        ValueError
            If credentials are invalid.
        """
        user = UserModel.find_by_username(username)
        if not user:
            raise ValueError("Invalid username or password.")

        if not check_password(user.get("password_hash"), password):
            raise ValueError("Invalid username or password.")

        UserModel.update_last_login(str(user["_id"]))
        # Refresh so last_login is included in the response
        user = UserModel.find_by_username(username)
        return UserModel.to_public_dict(user)

    @staticmethod
    def register_user(username, password, role="officer"):
        """
        Create a new user with a hashed password.
        Intended for seeding / admin use, not a public signup endpoint.
        """
        if not username or not password:
            raise ValueError("username and password are required.")
        if len(password) < 6:
            raise ValueError("password must be at least 6 characters.")

        password_hash = hash_password(password)
        user_id = UserModel.create_user(username, password_hash, role=role)
        user = UserModel.find_by_id(user_id)
        return UserModel.to_public_dict(user)
