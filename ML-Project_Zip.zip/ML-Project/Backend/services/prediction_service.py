"""
Prediction service – machine learning operations only.

Responsibilities:
- Load Random Forest model and preprocessor once at startup
- Transform applicant data with preprocessor.transform() (never fit())
- Generate predicted class + probability
- Return structured results for the frontend

This service does NOT retrain models and does NOT talk to MongoDB.
"""

import logging

import joblib
import pandas as pd

from config import Config

logger = logging.getLogger(__name__)

# Target encoding used during training (see Preprocessing.ipynb):
#   bad  -> 0
#   good -> 1
CLASS_LABELS = {
    0: "Bad Credit Risk",
    1: "Good Credit Risk",
}

RECOMMENDATION_NOTE = (
    "This prediction is a decision-support recommendation only. "
    "Final loan approval or rejection must be made by a loan officer."
)


class PredictionService:
    """Singleton-style service that keeps the model in memory."""

    _model = None
    _preprocessor = None
    _loaded = False

    @classmethod
    def load_artefacts(cls):
        """
        Load Random Forest model and preprocessing pipeline once.
        Called from app.py when Flask starts.
        """
        if cls._loaded:
            return

        model_path = Config.RF_MODEL_PATH
        preprocessor_path = Config.PREPROCESSOR_PATH

        if not model_path.exists():
            raise FileNotFoundError(
                f"Random Forest model not found at: {model_path}"
            )
        if not preprocessor_path.exists():
            raise FileNotFoundError(
                f"Preprocessor not found at: {preprocessor_path}. "
                "Ensure preprocessor.pkl exists in the Saved models folder."
            )

        logger.info("Loading Random Forest model from %s", model_path)
        cls._model = joblib.load(model_path)

        logger.info("Loading preprocessor from %s", preprocessor_path)
        cls._preprocessor = joblib.load(preprocessor_path)

        cls._loaded = True
        logger.info("ML artefacts loaded successfully (no retraining).")

    @classmethod
    def is_ready(cls):
        """Return True if model and preprocessor are loaded."""
        return cls._loaded and cls._model is not None and cls._preprocessor is not None

    @classmethod
    def predict(cls, applicant_data):
        """
        Run a credit-risk prediction for one applicant.

        Parameters
        ----------
        applicant_data : dict
            Validated feature dictionary with canonical column names.

        Returns
        -------
        dict
            Structured prediction result for the API / frontend.
        """
        if not cls.is_ready():
            # Lazy load if somehow not initialised at startup
            cls.load_artefacts()

        try:
            # Convert incoming applicant info into a single-row DataFrame
            # Column order must match the training feature schema.
            df = pd.DataFrame([applicant_data])

            # IMPORTANT: use transform() only – never fit() again
            features = cls._preprocessor.transform(df)

            # Predicted class (0 = Bad, 1 = Good)
            predicted_class = int(cls._model.predict(features)[0])

            # Class probabilities [P(bad), P(good)]
            probabilities = cls._model.predict_proba(features)[0]
            prob_bad = float(probabilities[0])
            prob_good = float(probabilities[1])

            # Confidence = probability of the predicted class
            confidence = float(probabilities[predicted_class])
            prediction_label = CLASS_LABELS.get(
                predicted_class, f"Unknown ({predicted_class})"
            )

            return {
                "prediction_class": predicted_class,
                "prediction_label": prediction_label,
                "probability": round(confidence, 4),
                "confidence": round(confidence, 4),
                "probabilities": {
                    "bad_credit_risk": round(prob_bad, 4),
                    "good_credit_risk": round(prob_good, 4),
                },
                "model_name": "Random Forest",
                "recommendation_note": RECOMMENDATION_NOTE,
            }
        except Exception as exc:
            logger.exception("Prediction failed")
            raise RuntimeError(f"Prediction failed: {exc}") from exc
