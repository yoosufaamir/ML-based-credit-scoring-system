"""
History service – prediction history business logic.
"""

from models import PredictionModel


class HistoryService:
    """Business logic for prediction history operations."""

    @staticmethod
    def save_prediction(applicant_data, prediction_result, created_by=None):
        """Persist a prediction and return the stored record."""
        return PredictionModel.create(
            applicant_data=applicant_data,
            prediction_result=prediction_result,
            created_by=created_by,
        )

    @staticmethod
    def list_history(limit=100):
        """Return all prediction records (newest first)."""
        return PredictionModel.get_all(limit=limit)

    @staticmethod
    def get_prediction(prediction_id):
        """Return one prediction or None if it does not exist."""
        return PredictionModel.get_by_id(prediction_id)

    @staticmethod
    def delete_prediction(prediction_id):
        """Delete one prediction. Returns True if deleted."""
        return PredictionModel.delete_by_id(prediction_id)
