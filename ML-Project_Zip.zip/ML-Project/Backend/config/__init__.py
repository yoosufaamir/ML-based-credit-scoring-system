"""Configuration package for the Credit Scoring backend."""

from config.config import Config

__all__ = ["Config"]
