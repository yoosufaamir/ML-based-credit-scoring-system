"""
Application configuration.
Loads settings from environment variables (.env) with sensible defaults.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Backend root and project root (ML-Project)
BACKEND_ROOT = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BACKEND_ROOT.parent

# Load .env from the Backend folder
load_dotenv(BACKEND_ROOT / ".env")


class Config:
    """Central configuration used across the Flask application."""

    # Flask
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")
    DEBUG = os.getenv("FLASK_DEBUG", "True").lower() in ("1", "true", "yes")

    # MongoDB
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "credit_scoring_db")

    # CORS – allow only the React frontend
    CORS_ORIGINS = [
        origin.strip()
        for origin in os.getenv(
            "CORS_ORIGINS",
            "http://localhost:3000,http://127.0.0.1:3000,http://localhost:5173,http://127.0.0.1:5173",
        ).split(",")
        if origin.strip()
    ]

    # Machine learning artefacts (never exposed via API)
    SAVED_MODELS_DIR = Path(
        os.getenv("SAVED_MODELS_DIR", str(PROJECT_ROOT / "Saved models"))
    )
    RF_MODEL_PATH = Path(
        os.getenv("RF_MODEL_PATH", str(SAVED_MODELS_DIR / "Random_forest.pkl"))
    )
    PREPROCESSOR_PATH = Path(
        os.getenv("PREPROCESSOR_PATH", str(SAVED_MODELS_DIR / "preprocessor.pkl"))
    )

    # Server
    HOST = os.getenv("FLASK_HOST", "0.0.0.0")
    PORT = int(os.getenv("FLASK_PORT", "5000"))
