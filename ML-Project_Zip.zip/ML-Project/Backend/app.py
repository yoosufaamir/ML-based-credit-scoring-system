"""
ML-Based Credit Scoring System – Flask Backend
----------------------------------------------
Entry point for the application.

Responsibilities of this file:
1. Create the Flask application
2. Enable CORS for the React frontend
3. Connect to MongoDB
4. Load the saved Random Forest model and preprocessor (no retraining)
5. Register all API route blueprints

Run:
    python app.py
"""

import logging
import sys
from pathlib import Path

from flask import Flask, jsonify
from flask_cors import CORS

# Ensure the Backend directory is on sys.path when running app.py directly
BACKEND_ROOT = Path(__file__).resolve().parent
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

from config import Config
from database import init_db, close_db
from routes import auth_bp, prediction_bp, history_bp
from services import PredictionService
from utils.responses import error_response


def create_app():
    """Application factory – builds and configures the Flask app."""
    app = Flask(__name__)
    app.config.from_object(Config)

    # Logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # Restrict CORS to the React frontend origin(s)
    CORS(
        app,
        resources={r"/api/*": {"origins": Config.CORS_ORIGINS}},
        supports_credentials=True,
    )

    # Connect to MongoDB
    init_db(app)

    # Load ML artefacts once at startup (Random Forest + preprocessor)
    PredictionService.load_artefacts()

    # Register API blueprints under /api
    app.register_blueprint(auth_bp, url_prefix="/api")
    app.register_blueprint(prediction_bp, url_prefix="/api")
    app.register_blueprint(history_bp, url_prefix="/api")

    @app.route("/api/health", methods=["GET"])
    def health_check():
        """Simple health endpoint for Postman / deployment checks."""
        return jsonify(
            {
                "success": True,
                "message": "Credit Scoring API is running.",
                "model_loaded": PredictionService.is_ready(),
                "model": "Random Forest",
            }
        ), 200

    @app.errorhandler(404)
    def not_found(error):
        return error_response("Endpoint not found.", status_code=404)

    @app.errorhandler(405)
    def method_not_allowed(error):
        return error_response("Method not allowed.", status_code=405)

    @app.errorhandler(500)
    def internal_error(error):
        return error_response("Internal server error.", status_code=500)

    @app.teardown_appcontext
    def shutdown_session(exception=None):
        # Reserved for per-request cleanup; global client closed on exit
        pass

    return app


app = create_app()


if __name__ == "__main__":
    try:
        app.logger.info(
            "Starting Credit Scoring backend on %s:%s",
            Config.HOST,
            Config.PORT,
        )
        app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
    finally:
        close_db()
