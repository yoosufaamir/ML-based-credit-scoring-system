"""
Password hashing utilities.
Uses Werkzeug so plain-text passwords are never stored in MongoDB.
"""

from werkzeug.security import generate_password_hash, check_password_hash


def hash_password(plain_password):
    """Hash a plain-text password for secure storage."""
    return generate_password_hash(plain_password)


def check_password(password_hash, plain_password):
    """Return True if the plain password matches the stored hash."""
    if not password_hash or not plain_password:
        return False
    return check_password_hash(password_hash, plain_password)
