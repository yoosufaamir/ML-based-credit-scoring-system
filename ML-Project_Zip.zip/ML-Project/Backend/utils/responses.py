"""
Standard JSON response helpers for consistent API output.
"""

from flask import jsonify


def success_response(message, data=None, status_code=200):
    """Build a successful JSON response."""
    payload = {"success": True, "message": message}
    if data is not None:
        payload["data"] = data
    return jsonify(payload), status_code


def error_response(message, status_code=400, errors=None):
    """Build an error JSON response with an optional list of field errors."""
    payload = {"success": False, "message": message}
    if errors is not None:
        payload["errors"] = errors
    return jsonify(payload), status_code
