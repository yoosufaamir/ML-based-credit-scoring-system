"""
Input validation for login and credit-scoring prediction requests.

Validates:
- required fields are present
- numeric fields are > 0 (where appropriate)
- categorical values match those used during model training
"""

# Canonical feature names expected by the saved preprocessor / Random Forest model
NUMERIC_FIELDS = {
    "Loan_duration": {"min": 1, "type": int},
    "credit_amount'(000)": {"min": 1, "type": int},
    "payment_to_income_ratio": {"min": 1, "type": int},
    "residence_since": {"min": 1, "type": int},
    "age": {"min": 1, "type": int},
    "n_credits": {"min": 1, "type": int},
    "n_guarantors": {"min": 1, "type": int},
}

# Allowed categories (exact values from the German Credit Dataset used in training)
CATEGORICAL_FIELDS = {
    "status_account": [
        "0 to < 200 DM",
        "< 0 DM",
        ">= 200 DM",
        "no checking account",
    ],
    "credit_history": [
        "all credits at this bank paid back duly",
        "critical account/ other credits existing (not at this bank)",
        "delay in paying off in the past",
        "existing credits paid back duly till now",
        "no credits taken/ all credits paid back duly",
    ],
    "Loan_purpose": [
        "business",
        "car (new)",
        "car (used)",
        "domestic appliances",
        "education",
        "furniture/equipment",
        "others",
        "radio/television",
        "repairs",
        "retraining",
    ],
    "status_savings": [
        "100 to < 500 DM",
        "500 to < 1000 DM",
        "< 100 DM",
        ">= 1000 DM",
        "unknown/ no savings account",
    ],
    "employment_since": [
        "1 to < 4 years",
        "4 to < 7 years",
        "< 1 year",
        ">= 7 years",
        "unemployed",
    ],
    "status_and_sex": [
        "female : divorced/separated/married",
        "male : divorced/separated",
        "male : married/widowed",
        "male : single",
    ],
    "secondary_obligor": ["co-applicant", "guarantor", "none"],
    "collateral": [
        "car",
        "none",
        "real estate",
        "savings agreement/life insurance",
    ],
    "other_installment_plans": ["bank", "none", "stores"],
    "Housing_ownership": ["for free", "own", "rent"],
    "job": [
        "management/ self-employed/highly qualified employee",
        "skilled employee/ official",
        "unemployed/ unskilled - non-resident",
        "unskilled - resident",
    ],
    "telephone": [
        "none",
        "yes, registered under the customers name",
    ],
    "work_eligibility_status": ["no", "yes"],
}

# Friendly aliases accepted from the frontend / Postman
FIELD_ALIASES = {
    "credit_amount": "credit_amount'(000)",
    "credit_amount_000": "credit_amount'(000)",
    "loan_duration": "Loan_duration",
    "loan_purpose": "Loan_purpose",
    "housing_ownership": "Housing_ownership",
}

REQUIRED_FIELDS = list(NUMERIC_FIELDS.keys()) + list(CATEGORICAL_FIELDS.keys())


def _normalise_payload(data):
    """Map aliases to canonical column names and strip string values."""
    if not isinstance(data, dict):
        return {}

    normalised = {}
    for key, value in data.items():
        canonical = FIELD_ALIASES.get(key, key)
        if isinstance(value, str):
            value = value.strip()
        normalised[canonical] = value
    return normalised


def validate_login_payload(data):
    """
    Validate login JSON.
    Returns (cleaned_data, errors). errors is empty on success.
    """
    errors = []
    if not isinstance(data, dict):
        return None, ["Request body must be a JSON object."]

    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if not username:
        errors.append("username is required.")
    if not password:
        errors.append("password is required.")

    if errors:
        return None, errors

    return {"username": username, "password": password}, []


def validate_applicant_data(data):
    """
    Validate applicant feature JSON before prediction.

    Returns
    -------
    cleaned : dict or None
        Canonical feature dictionary ready for the preprocessor.
    errors : list
        Human-readable validation messages (empty if valid).
    """
    if not isinstance(data, dict):
        return None, ["Request body must be a JSON object."]

    # Ignore nested metadata keys if the frontend wraps the applicant object
    if "applicant" in data and isinstance(data["applicant"], dict):
        data = data["applicant"]

    payload = _normalise_payload(data)
    errors = []
    cleaned = {}

    # Required fields
    missing = [field for field in REQUIRED_FIELDS if field not in payload]
    if missing:
        # Present credit amount under a friendlier name in messages
        display_missing = [
            "credit_amount" if f == "credit_amount'(000)" else f for f in missing
        ]
        errors.append(f"Missing required field(s): {', '.join(display_missing)}.")

    # Numeric validation
    for field, rules in NUMERIC_FIELDS.items():
        if field not in payload:
            continue
        raw = payload[field]
        try:
            value = float(raw)
            if rules["type"] is int:
                if not float(value).is_integer():
                    raise ValueError("not an integer")
                value = int(value)
        except (TypeError, ValueError):
            display = "credit_amount" if field == "credit_amount'(000)" else field
            errors.append(f"{display} must be a valid number.")
            continue

        if value < rules["min"]:
            display = "credit_amount" if field == "credit_amount'(000)" else field
            errors.append(f"{display} must be greater than or equal to {rules['min']}.")
            continue

        cleaned[field] = value

    # Categorical validation
    for field, allowed in CATEGORICAL_FIELDS.items():
        if field not in payload:
            continue
        value = payload[field]
        if value not in allowed:
            errors.append(
                f"Invalid value for '{field}'. Allowed values: {allowed}."
            )
            continue
        cleaned[field] = value

    if errors:
        return None, errors

    return cleaned, []
