"""
User data-access layer.
Users collection fields:
  username, password_hash, role, created_at, last_login
"""

from datetime import datetime, timezone

from bson import ObjectId
from bson.errors import InvalidId
from pymongo.errors import DuplicateKeyError, PyMongoError

from database import get_db


class UserModel:
    """CRUD helpers for the users collection."""

    COLLECTION = "users"

    @staticmethod
    def _collection():
        return get_db()[UserModel.COLLECTION]

    @staticmethod
    def create_user(username, password_hash, role="officer"):
        """Insert a new user. Returns the inserted document id as a string."""
        document = {
            "username": username.strip(),
            "password_hash": password_hash,
            "role": role,
            "created_at": datetime.now(timezone.utc),
            "last_login": None,
        }
        try:
            result = UserModel._collection().insert_one(document)
            return str(result.inserted_id)
        except DuplicateKeyError as exc:
            raise ValueError(f"Username '{username}' already exists.") from exc
        except PyMongoError as exc:
            raise RuntimeError(f"Database error while creating user: {exc}") from exc

    @staticmethod
    def find_by_username(username):
        """Return a user document by username, or None."""
        try:
            return UserModel._collection().find_one({"username": username.strip()})
        except PyMongoError as exc:
            raise RuntimeError(f"Database error while finding user: {exc}") from exc

    @staticmethod
    def find_by_id(user_id):
        """Return a user document by ObjectId string, or None."""
        try:
            return UserModel._collection().find_one({"_id": ObjectId(user_id)})
        except (InvalidId, PyMongoError):
            return None

    @staticmethod
    def update_last_login(user_id):
        """Set last_login to the current UTC time."""
        try:
            UserModel._collection().update_one(
                {"_id": ObjectId(user_id)},
                {"$set": {"last_login": datetime.now(timezone.utc)}},
            )
        except (InvalidId, PyMongoError) as exc:
            raise RuntimeError(f"Database error while updating last login: {exc}") from exc

    @staticmethod
    def to_public_dict(user):
        """Serialise a user document for API responses (no password hash)."""
        if not user:
            return None
        return {
            "id": str(user["_id"]),
            "username": user.get("username"),
            "role": user.get("role"),
            "created_at": user.get("created_at").isoformat()
            if user.get("created_at")
            else None,
            "last_login": user.get("last_login").isoformat()
            if user.get("last_login")
            else None,
        }
