"""
Prediction history data-access layer.
Predictions collection stores applicant details, result, probability, and timestamp.
"""

from datetime import datetime, timezone

from bson import ObjectId
from bson.errors import InvalidId
from pymongo.errors import PyMongoError

from database import get_db


class PredictionModel:
    """CRUD helpers for the predictions collection."""

    COLLECTION = "predictions"

    @staticmethod
    def _collection():
        return get_db()[PredictionModel.COLLECTION]

    @staticmethod
    def create(applicant_data, prediction_result, created_by=None):
        """
        Store a prediction record.

        Parameters
        ----------
        applicant_data : dict
            Original (validated) applicant feature values.
        prediction_result : dict
            Structured output from the prediction service.
        created_by : str, optional
            Username of the officer who requested the prediction.
        """
        document = {
            "applicant": applicant_data,
            "prediction_label": prediction_result.get("prediction_label"),
            "prediction_class": prediction_result.get("prediction_class"),
            "probability": prediction_result.get("probability"),
            "confidence": prediction_result.get("confidence"),
            "probabilities": prediction_result.get("probabilities"),
            "model_name": prediction_result.get("model_name", "Random Forest"),
            "recommendation_note": prediction_result.get("recommendation_note"),
            "created_by": created_by,
            "created_at": datetime.now(timezone.utc),
        }
        try:
            result = PredictionModel._collection().insert_one(document)
            document["_id"] = result.inserted_id
            return PredictionModel.to_public_dict(document)
        except PyMongoError as exc:
            raise RuntimeError(f"Database error while saving prediction: {exc}") from exc

    @staticmethod
    def get_all(limit=100):
        """Return prediction records sorted by newest first."""
        try:
            cursor = (
                PredictionModel._collection()
                .find()
                .sort("created_at", -1)
                .limit(limit)
            )
            return [PredictionModel.to_public_dict(doc) for doc in cursor]
        except PyMongoError as exc:
            raise RuntimeError(f"Database error while fetching history: {exc}") from exc

    @staticmethod
    def get_by_id(prediction_id):
        """Return a single prediction by id, or None if not found."""
        try:
            doc = PredictionModel._collection().find_one(
                {"_id": ObjectId(prediction_id)}
            )
            return PredictionModel.to_public_dict(doc) if doc else None
        except InvalidId:
            return None
        except PyMongoError as exc:
            raise RuntimeError(f"Database error while fetching prediction: {exc}") from exc

    @staticmethod
    def delete_by_id(prediction_id):
        """
        Delete a prediction by id.
        Returns True if a document was deleted, False if not found.
        """
        try:
            result = PredictionModel._collection().delete_one(
                {"_id": ObjectId(prediction_id)}
            )
            return result.deleted_count == 1
        except InvalidId:
            return False
        except PyMongoError as exc:
            raise RuntimeError(f"Database error while deleting prediction: {exc}") from exc

    @staticmethod
    def to_public_dict(doc):
        """Convert a MongoDB document into a JSON-serialisable dictionary."""
        if not doc:
            return None
        return {
            "id": str(doc["_id"]),
            "applicant": doc.get("applicant", {}),
            "prediction_label": doc.get("prediction_label"),
            "prediction_class": doc.get("prediction_class"),
            "probability": doc.get("probability"),
            "confidence": doc.get("confidence"),
            "probabilities": doc.get("probabilities"),
            "model_name": doc.get("model_name"),
            "recommendation_note": doc.get("recommendation_note"),
            "created_by": doc.get("created_by"),
            "created_at": doc.get("created_at").isoformat()
            if doc.get("created_at")
            else None,
        }
