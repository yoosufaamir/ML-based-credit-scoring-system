"""
Authentication routes.
Routes only handle HTTP request/response wiring.
"""

from flask import Blueprint, request

from controllers import AuthController

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    """POST /api/login – authenticate a user against MongoDB."""
    return AuthController.login(request.get_json(silent=True))
