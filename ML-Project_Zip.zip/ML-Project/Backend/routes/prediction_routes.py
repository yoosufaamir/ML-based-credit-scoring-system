"""
Prediction routes.
"""

from flask import Blueprint, request

from controllers import PredictionController

prediction_bp = Blueprint("prediction", __name__)


@prediction_bp.route("/predict", methods=["POST"])
def predict():
    """
    POST /api/predict
    Accept applicant JSON, run Random Forest prediction, store history.
    """
    return PredictionController.predict(request.get_json(silent=True))
