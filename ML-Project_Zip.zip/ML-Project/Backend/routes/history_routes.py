"""
Prediction history routes.
"""

from flask import Blueprint

from controllers import HistoryController

history_bp = Blueprint("history", __name__)


@history_bp.route("/history", methods=["GET"])
def list_history():
    """GET /api/history – return all predictions (newest first)."""
    return HistoryController.list_history()


@history_bp.route("/history/<prediction_id>", methods=["GET"])
def get_history_item(prediction_id):
    """GET /api/history/<id> – return a single prediction."""
    return HistoryController.get_history_item(prediction_id)


@history_bp.route("/history/<prediction_id>", methods=["DELETE"])
def delete_history_item(prediction_id):
    """DELETE /api/history/<id> – remove a prediction record."""
    return HistoryController.delete_history_item(prediction_id)
