"""API route blueprints."""

from routes.auth_routes import auth_bp
from routes.prediction_routes import prediction_bp
from routes.history_routes import history_bp

__all__ = ["auth_bp", "prediction_bp", "history_bp"]
