# ML-Based Credit Scoring System – Flask Backend

Backend for the final-year project **ML-Based Credit Scoring System for Banking Loan Evaluation**.

It connects the React frontend, the saved Random Forest model, and MongoDB.  
Models are **never retrained** here — only loaded for inference.

## Architecture

```
Backend/
├── app.py                 # Flask entry point (CORS, DB, routes, model load)
├── requirements.txt
├── .env
├── config/                # Environment configuration
├── database/              # MongoDB connection (PyMongo)
├── models/                # Users & Predictions data access
├── utils/                 # Validation, password hashing, responses
├── services/              # Auth, prediction (ML), history business logic
├── controllers/           # Request orchestration
├── routes/                # REST API blueprints
└── scripts/               # Seed admin user & API smoke tests
```

## Prerequisites

- Python 3.10+
- MongoDB running locally (`mongodb://localhost:27017`)
- Saved artefacts in `../Saved models/`:
  - `Random_forest.pkl`
  - `preprocessor.pkl`

## Setup

```bash
cd Backend
pip install -r requirements.txt
python scripts/seed_admin.py
python app.py
```

Default demo user:

- **username:** `admin`
- **password:** `admin123`

API base URL: `http://127.0.0.1:5000/api`

## Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/login` | Authenticate user |
| POST | `/api/predict` | Validate → preprocess → Random Forest predict → save |
| GET | `/api/history` | List predictions (newest first) |
| GET | `/api/history/<id>` | Get one prediction |
| DELETE | `/api/history/<id>` | Delete one prediction |

### Login body

```json
{
  "username": "admin",
  "password": "admin123"
}
```

### Predict body (example)

```json
{
  "status_account": "< 0 DM",
  "Loan_duration": 12,
  "credit_history": "existing credits paid back duly till now",
  "Loan_purpose": "radio/television",
  "credit_amount": 2500,
  "status_savings": "< 100 DM",
  "employment_since": "1 to < 4 years",
  "payment_to_income_ratio": 2,
  "status_and_sex": "male : single",
  "secondary_obligor": "none",
  "residence_since": 2,
  "collateral": "none",
  "age": 35,
  "other_installment_plans": "none",
  "Housing_ownership": "own",
  "n_credits": 1,
  "job": "skilled employee/ official",
  "n_guarantors": 1,
  "telephone": "none",
  "work_eligibility_status": "yes"
}
```

`credit_amount` is accepted as an alias for the training column `credit_amount'(000)`.

## Prediction labels

Training encoding:

- `0` → **Bad Credit Risk**
- `1` → **Good Credit Risk**

Predictions are decision-support recommendations only; loan officers make the final decision.

## Testing

With the server running:

```bash
python scripts/test_api.py
```

Or import the same requests into Postman using the table above.

## Security notes

- Passwords are hashed with Werkzeug (never stored in plain text)
- CORS is restricted to configured frontend origins
- Model `.pkl` files stay on the server and are not exposed via API
