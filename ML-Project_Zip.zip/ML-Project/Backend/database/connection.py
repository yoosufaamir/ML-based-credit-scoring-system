"""
MongoDB connection module.
Establishes a PyMongo connection when the Flask application starts.
"""

from flask import current_app, g
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError

from config import Config

# Module-level client reused across requests
_client = None
_db = None


def init_db(app):
    """
    Initialise the MongoDB connection when Flask starts.
    Stores the client on the app object and verifies connectivity.
    """
    global _client, _db

    mongo_uri = app.config.get("MONGO_URI", Config.MONGO_URI)
    db_name = app.config.get("MONGO_DB_NAME", Config.MONGO_DB_NAME)

    try:
        _client = MongoClient(
            mongo_uri,
            serverSelectionTimeoutMS=5000,
        )
        # Force a round-trip to confirm the server is reachable
        _client.admin.command("ping")
        _db = _client[db_name]

        # Useful indexes for common queries
        _db.users.create_index("username", unique=True)
        _db.predictions.create_index("created_at")

        app.logger.info("Connected to MongoDB database '%s'", db_name)
    except (ConnectionFailure, ServerSelectionTimeoutError) as exc:
        app.logger.error("Failed to connect to MongoDB: %s", exc)
        raise RuntimeError(
            f"Could not connect to MongoDB at {mongo_uri}. "
            "Ensure MongoDB is running before starting the backend."
        ) from exc

    @app.teardown_appcontext
    def teardown_db(exception=None):
        # Per-request handle cleanup (client itself stays open for app lifetime)
        g.pop("db", None)


def get_db():
    """
    Return the active MongoDB database instance.
    Prefer the module-level connection created at startup.
    """
    if _db is not None:
        return _db

    # Fallback for contexts where init_db has not run yet
    if "db" not in g:
        client = MongoClient(Config.MONGO_URI, serverSelectionTimeoutMS=5000)
        g.db = client[Config.MONGO_DB_NAME]
    return g.db


def close_db():
    """Close the global MongoDB client (used on application shutdown)."""
    global _client, _db
    if _client is not None:
        _client.close()
        _client = None
        _db = None
