"""
History controller.
Handles listing, retrieving, and deleting prediction records.
"""

from services import HistoryService
from utils.responses import success_response, error_response


class HistoryController:
    """HTTP-facing logic for prediction history endpoints."""

    @staticmethod
    def list_history():
        """Handle GET /api/history."""
        try:
            records = HistoryService.list_history()
            return success_response(
                "Prediction history retrieved successfully.",
                data={"count": len(records), "history": records},
            )
        except RuntimeError as exc:
            return error_response(str(exc), status_code=500)
        except Exception as exc:
            return error_response(
                f"Unexpected error while fetching history: {exc}",
                status_code=500,
            )

    @staticmethod
    def get_history_item(prediction_id):
        """Handle GET /api/history/<id>."""
        try:
            if not prediction_id:
                return error_response("Prediction id is required.", status_code=400)

            record = HistoryService.get_prediction(prediction_id)
            if not record:
                return error_response(
                    f"Prediction with id '{prediction_id}' was not found.",
                    status_code=404,
                )

            return success_response(
                "Prediction retrieved successfully.",
                data={"record": record},
            )
        except RuntimeError as exc:
            return error_response(str(exc), status_code=500)
        except Exception as exc:
            return error_response(
                f"Unexpected error while fetching prediction: {exc}",
                status_code=500,
            )

    @staticmethod
    def delete_history_item(prediction_id):
        """Handle DELETE /api/history/<id>."""
        try:
            if not prediction_id:
                return error_response("Prediction id is required.", status_code=400)

            deleted = HistoryService.delete_prediction(prediction_id)
            if not deleted:
                return error_response(
                    f"Prediction with id '{prediction_id}' was not found.",
                    status_code=404,
                )

            return success_response(
                "Prediction deleted successfully.",
                data={"id": prediction_id},
            )
        except RuntimeError as exc:
            return error_response(str(exc), status_code=500)
        except Exception as exc:
            return error_response(
                f"Unexpected error while deleting prediction: {exc}",
                status_code=500,
            )
