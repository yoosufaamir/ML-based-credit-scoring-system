"""
Prediction controller.
Validates applicant data, runs ML prediction, and stores history.
"""

from services import PredictionService, HistoryService
from utils.validators import validate_applicant_data
from utils.responses import success_response, error_response


class PredictionController:
    """HTTP-facing logic for the prediction endpoint."""

    @staticmethod
    def predict(request_json, created_by=None):
        """
        Handle POST /api/predict.
        Flow: validate -> preprocess/predict -> save -> respond.
        """
        try:
            cleaned, errors = validate_applicant_data(request_json)
            if errors:
                return error_response(
                    "Validation failed.",
                    status_code=400,
                    errors=errors,
                )

            # Optional username from body (frontend may send it after login)
            if created_by is None and isinstance(request_json, dict):
                created_by = request_json.get("created_by") or request_json.get(
                    "username"
                )

            prediction = PredictionService.predict(cleaned)
            record = HistoryService.save_prediction(
                applicant_data=cleaned,
                prediction_result=prediction,
                created_by=created_by,
            )

            return success_response(
                "Prediction generated successfully.",
                data={
                    "prediction": prediction,
                    "record": record,
                },
                status_code=200,
            )
        except ValueError as exc:
            return error_response(str(exc), status_code=400)
        except FileNotFoundError as exc:
            return error_response(str(exc), status_code=500)
        except RuntimeError as exc:
            return error_response(str(exc), status_code=500)
        except Exception as exc:
            return error_response(
                f"Unexpected error during prediction: {exc}",
                status_code=500,
            )
