"""
Authentication controller.
Coordinates validation and auth service calls for login requests.
"""

from services import AuthService
from utils.validators import validate_login_payload
from utils.responses import success_response, error_response


class AuthController:
    """HTTP-facing logic for authentication endpoints."""

    @staticmethod
    def login(request_json):
        """
        Handle POST /api/login.
        Validates credentials and returns user info or an error response.
        """
        try:
            cleaned, errors = validate_login_payload(request_json)
            if errors:
                return error_response(
                    "Validation failed.",
                    status_code=400,
                    errors=errors,
                )

            user = AuthService.login(cleaned["username"], cleaned["password"])
            return success_response(
                "Login successful.",
                data={"user": user},
                status_code=200,
            )
        except ValueError as exc:
            return error_response(str(exc), status_code=401)
        except RuntimeError as exc:
            return error_response(str(exc), status_code=500)
        except Exception as exc:
            return error_response(
                f"Unexpected error during login: {exc}",
                status_code=500,
            )
