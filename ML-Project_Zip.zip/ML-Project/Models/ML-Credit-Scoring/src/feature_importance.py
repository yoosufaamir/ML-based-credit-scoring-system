"""
STEP 6 – Feature Importance
---------------------------
Display which input features most influence the selected model's predictions.
This helps loan officers understand why a recommendation was made
(useful for a Decision Support System / explainability).
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def get_transformed_feature_names(pipeline):
    """
    Get feature names after One-Hot Encoding from the fitted preprocessor.

    Parameters
    ----------
    pipeline : sklearn.pipeline.Pipeline
        Trained pipeline with a 'preprocessor' step.

    Returns
    -------
    list of str
        Names of transformed features.
    """
    preprocessor = pipeline.named_steps["preprocessor"]
    feature_names = preprocessor.get_feature_names_out()
    return list(feature_names)


def extract_feature_importance(pipeline, model_name):
    """
    Extract feature importance (or coefficients) from the selected model.

    - Random Forest / XGBoost: use feature_importances_
    - Logistic Regression: use absolute value of coefficients
      (larger |coef| = stronger influence on the decision)

    Returns
    -------
    pandas.DataFrame
        Feature names and importance scores sorted descending.
    """
    classifier = pipeline.named_steps["classifier"]
    feature_names = get_transformed_feature_names(pipeline)

    if hasattr(classifier, "feature_importances_"):
        # Tree-based models (Random Forest, XGBoost)
        importances = classifier.feature_importances_
        importance_type = "Feature Importance"
    elif hasattr(classifier, "coef_"):
        # Logistic Regression: coefficients can be positive or negative
        # We use absolute values to rank overall influence
        importances = np.abs(classifier.coef_[0])
        importance_type = "Absolute Coefficient"
    else:
        raise ValueError(f"Cannot extract feature importance from {model_name}")

    importance_df = pd.DataFrame(
        {
            "Feature": feature_names,
            importance_type: importances,
        }
    ).sort_values(by=importance_type, ascending=False)

    # Clean column name for consistent plotting
    importance_df = importance_df.rename(columns={importance_type: "Importance"})
    return importance_df


def plot_feature_importance(importance_df, model_name, results_dir, top_n=20):
    """
    Plot the top N most important features as a horizontal bar chart.

    Parameters
    ----------
    importance_df : pandas.DataFrame
        Sorted feature importance table.
    model_name : str
        Name of the selected model (used in the chart title).
    results_dir : str
        Folder to save the plot and CSV.
    top_n : int
        Number of top features to display.
    """
    os.makedirs(results_dir, exist_ok=True)

    top_features = importance_df.head(top_n).iloc[::-1]  # reverse for nicer bar order

    fig, ax = plt.subplots(figsize=(10, 8))
    ax.barh(top_features["Feature"], top_features["Importance"], color="steelblue")
    ax.set_xlabel("Importance Score")
    ax.set_ylabel("Feature")
    ax.set_title(f"Top {top_n} Feature Importances – {model_name}")
    fig.tight_layout()

    plot_path = os.path.join(results_dir, "feature_importance.png")
    fig.savefig(plot_path, dpi=150)
    plt.close(fig)

    csv_path = os.path.join(results_dir, "feature_importance.csv")
    importance_df.to_csv(csv_path, index=False)

    print(f"\nFeature importance plot saved to: {plot_path}")
    print(f"Feature importance table saved to: {csv_path}")


def analyse_feature_importance(pipeline, model_name, results_dir, top_n=20):
    """
    STEP 6 entry point: extract, display, plot, and explain feature importance.

    Returns
    -------
    pandas.DataFrame
        Full feature importance ranking.
    """
    print("\n" + "=" * 70)
    print("STEP 6: FEATURE IMPORTANCE")
    print("=" * 70)

    importance_df = extract_feature_importance(pipeline, model_name)

    print(f"\nTop {top_n} most influential features for {model_name}:")
    print(importance_df.head(top_n).to_string(index=False))

    plot_feature_importance(importance_df, model_name, results_dir, top_n=top_n)

    # Brief explanation for the project report
    top3 = importance_df.head(3)["Feature"].tolist()
    print("\nInterpretation:")
    print(
        f"The features with the greatest influence on the prediction are: "
        f"{', '.join(top3)}."
    )
    print(
        "Higher importance means the model relied more on that feature when "
        "estimating credit risk. Loan officers can use this information as "
        "supporting context, but the final lending decision remains human-made."
    )

    return importance_df
