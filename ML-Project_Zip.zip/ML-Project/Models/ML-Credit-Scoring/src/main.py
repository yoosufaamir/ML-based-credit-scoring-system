"""
ML-Based Credit Scoring System for Banking Loan Evaluation
----------------------------------------------------------
Main pipeline script for the Machine Learning phase only.

This script runs Steps 1–7:
1. Load and understand the German Credit Dataset
2. Preprocess the data
3. Train Logistic Regression, Random Forest, and XGBoost
4. Evaluate all models
5. Select the best model
6. Analyse feature importance
7. Save the final model and preprocessing objects with Joblib

IMPORTANT:
The model prediction is only a recommendation for loan officers.
It must NEVER automatically approve or reject a loan.
"""

import os
import json
import joblib

from load_data import load_dataset, explore_dataset
from preprocess import preprocess_pipeline
from train_models import train_all_models
from evaluate import evaluate_all_models, select_best_model
from feature_importance import analyse_feature_importance


def get_project_paths():
    """Return important project folder paths."""
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return {
        "root": project_root,
        "models": os.path.join(project_root, "models"),
        "results": os.path.join(project_root, "results"),
        "dataset": os.path.join(project_root, "dataset"),
    }


def save_final_model(best_model, best_name, label_mapping, explanation, paths):
    """
    STEP 7 – Save the selected model and related objects using Joblib.

    Saved artefacts:
    - best_credit_model.joblib  : full pipeline (preprocessor + classifier)
    - label_mapping.joblib      : maps good/bad <-> 0/1
    - model_metadata.json       : model name and selection explanation

    The preprocessor is already inside the pipeline, so future predictions
    only need the saved pipeline (+ label mapping to decode class names).
    """
    print("\n" + "=" * 70)
    print("STEP 7: SAVE THE FINAL MODEL")
    print("=" * 70)

    os.makedirs(paths["models"], exist_ok=True)
    os.makedirs(paths["results"], exist_ok=True)

    model_path = os.path.join(paths["models"], "best_credit_model.joblib")
    mapping_path = os.path.join(paths["models"], "label_mapping.joblib")
    metadata_path = os.path.join(paths["models"], "model_metadata.json")

    # Save the full pipeline (includes preprocessing + trained classifier)
    joblib.dump(best_model, model_path)
    print(f"Saved best model pipeline to: {model_path}")

    # Save the target label mapping for converting predictions back to text
    # Example decode: {0: "good", 1: "bad"}
    inverse_mapping = {v: k for k, v in label_mapping.items()}
    joblib.dump(
        {"label_mapping": label_mapping, "inverse_mapping": inverse_mapping},
        mapping_path,
    )
    print(f"Saved label mapping to: {mapping_path}")

    # Save simple metadata for documentation / later API integration
    metadata = {
        "project": "ML-Based Credit Scoring System for Banking Loan Evaluation",
        "selected_model": best_name,
        "target_encoding": label_mapping,
        "inverse_encoding": {str(k): v for k, v in inverse_mapping.items()},
        "positive_class": "bad (high credit risk)",
        "decision_support_note": (
            "Model output is a recommendation only. "
            "Final loan approval/rejection must be made by a loan officer."
        ),
        "selection_explanation": explanation,
    }
    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    print(f"Saved model metadata to: {metadata_path}")

    # Also store the selection explanation in results/
    explanation_path = os.path.join(paths["results"], "model_selection_explanation.txt")
    with open(explanation_path, "w", encoding="utf-8") as f:
        f.write(explanation + "\n")
    print(f"Saved selection explanation to: {explanation_path}")


def main():
    """Run the complete Machine Learning pipeline."""
    paths = get_project_paths()

    print("=" * 70)
    print("ML-BASED CREDIT SCORING SYSTEM")
    print("Machine Learning Model Development Phase")
    print("=" * 70)
    print(
        "Decision Support System note: predictions are recommendations only. "
        "Loan officers make the final lending decision."
    )

    # ----- STEP 1: Load and understand -----
    df = load_dataset()
    explore_dataset(df)

    # ----- STEP 2: Preprocess -----
    data = preprocess_pipeline(df)
    X_train = data["X_train"]
    X_test = data["X_test"]
    y_train = data["y_train"]
    y_test = data["y_test"]
    preprocessor = data["preprocessor"]
    label_mapping = data["label_mapping"]

    # ----- STEP 3: Train models -----
    models = train_all_models(preprocessor, X_train, y_train)

    # ----- STEP 4: Evaluate -----
    comparison_df, _all_metrics = evaluate_all_models(
        models, X_test, y_test, paths["results"]
    )

    # ----- STEP 5: Select best model -----
    best_name, best_model, explanation = select_best_model(comparison_df, models)

    # ----- STEP 6: Feature importance -----
    analyse_feature_importance(best_model, best_name, paths["results"], top_n=20)

    # ----- STEP 7: Save artefacts -----
    save_final_model(best_model, best_name, label_mapping, explanation, paths)

    print("\n" + "=" * 70)
    print("PIPELINE COMPLETE")
    print("=" * 70)
    print(f"Best model: {best_name}")
    print(f"Saved artefacts are in: {paths['models']}")
    print(f"Evaluation plots/tables are in: {paths['results']}")
    print(
        "\nThis ML model is ready to be integrated into the web application "
        "(React.js + Flask + MongoDB) in later project phases."
    )


if __name__ == "__main__":
    main()
