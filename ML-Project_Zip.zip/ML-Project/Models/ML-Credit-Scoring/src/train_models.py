"""
STEP 3 – Train the Machine Learning Models
------------------------------------------
This module trains three classification models separately:
1. Logistic Regression
2. Random Forest
3. XGBoost

Each model is implemented in its own function for clear organisation.
Aligned with lecture concepts:
- Logistic Regression (Lecture #6): sigmoid / probability-based classification
- Random Forest (Lecture #7): ensemble of decision trees with majority voting
"""

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.pipeline import Pipeline


def train_logistic_regression(preprocessor, X_train, y_train):
    """
    Train a Logistic Regression classifier.

    Logistic Regression maps a linear combination of features through a
    sigmoid function to produce a probability between 0 and 1.
    If probability >= 0.5, we predict class 1 (bad / high risk).

    Parameters
    ----------
    preprocessor : ColumnTransformer
        Fitted/unfitted preprocessor (will be fitted inside the pipeline).
    X_train : DataFrame
        Training features (raw).
    y_train : Series
        Training labels.

    Returns
    -------
    sklearn.pipeline.Pipeline
        Pipeline containing preprocessor + Logistic Regression model.
    """
    print("\nTraining Logistic Regression...")

    # Pipeline: first transform features, then train the classifier
    model = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            (
                "classifier",
                LogisticRegression(
                    max_iter=1000,          # Allow enough iterations to converge
                    class_weight="balanced", # Handle imbalance (more good than bad)
                    random_state=42,
                ),
            ),
        ]
    )

    model.fit(X_train, y_train)
    print("Logistic Regression training complete.")
    return model


def train_random_forest(preprocessor, X_train, y_train):
    """
    Train a Random Forest classifier.

    Random Forest builds many decision trees on bootstrapped samples
    and random feature subsets, then uses majority voting for the final
    prediction (as covered in Lecture #7).

    Parameters
    ----------
    preprocessor : ColumnTransformer
        Preprocessor for encoding/scaling features.
    X_train : DataFrame
        Training features (raw).
    y_train : Series
        Training labels.

    Returns
    -------
    sklearn.pipeline.Pipeline
        Pipeline containing preprocessor + Random Forest model.
    """
    print("\nTraining Random Forest...")

    model = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            (
                "classifier",
                RandomForestClassifier(
                    n_estimators=200,        # Number of trees in the forest
                    max_depth=None,          # Let trees grow fully (can be tuned later)
                    class_weight="balanced", # Adjust for class imbalance
                    random_state=42,
                    n_jobs=-1,               # Use all CPU cores
                ),
            ),
        ]
    )

    model.fit(X_train, y_train)
    print("Random Forest training complete.")
    return model


def train_xgboost(preprocessor, X_train, y_train):
    """
    Train an XGBoost classifier.

    XGBoost builds trees sequentially. Each new tree focuses on correcting
    the mistakes of the previous trees (gradient boosting).

    Parameters
    ----------
    preprocessor : ColumnTransformer
        Preprocessor for encoding/scaling features.
    X_train : DataFrame
        Training features (raw).
    y_train : Series
        Training labels.

    Returns
    -------
    sklearn.pipeline.Pipeline
        Pipeline containing preprocessor + XGBoost model.
    """
    print("\nTraining XGBoost...")

    # Calculate scale_pos_weight to help with class imbalance
    # Formula: count(negative class) / count(positive class)
    neg_count = (y_train == 0).sum()
    pos_count = (y_train == 1).sum()
    scale_pos_weight = neg_count / pos_count if pos_count > 0 else 1.0

    model = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            (
                "classifier",
                XGBClassifier(
                    n_estimators=200,
                    learning_rate=0.1,
                    max_depth=5,
                    scale_pos_weight=scale_pos_weight,
                    eval_metric="logloss",
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    )

    model.fit(X_train, y_train)
    print("XGBoost training complete.")
    return model


def train_all_models(preprocessor, X_train, y_train):
    """
    Train all three models and return them in a dictionary.

    Important:
    Each model gets its own copy of the preprocessor so that
    fitting one model does not affect another.

    Returns
    -------
    dict
        Mapping of model name -> trained pipeline.
    """
    print("\n" + "=" * 70)
    print("STEP 3: TRAIN THE MACHINE LEARNING MODELS")
    print("=" * 70)

    from sklearn.base import clone

    models = {
        "Logistic Regression": train_logistic_regression(
            clone(preprocessor), X_train, y_train
        ),
        "Random Forest": train_random_forest(
            clone(preprocessor), X_train, y_train
        ),
        "XGBoost": train_xgboost(
            clone(preprocessor), X_train, y_train
        ),
    }

    print("\nAll three models have been trained successfully.")
    return models
