"""
STEP 2 – Data Preprocessing
---------------------------
This module prepares the German Credit Dataset for machine learning:
- Handle missing values
- Remove duplicate records
- Encode categorical attributes
- Separate features (X) and target (y)
- Split into 80% training and 20% testing
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer


def clean_data(df):
    """
    Clean the dataset by handling missing values and removing duplicates.

    Parameters
    ----------
    df : pandas.DataFrame
        Raw credit dataset.

    Returns
    -------
    pandas.DataFrame
        Cleaned dataset.
    """
    print("\n" + "=" * 70)
    print("STEP 2: DATA PREPROCESSING")
    print("=" * 70)

    df_clean = df.copy()

    # ----- Handle missing values -----
    # If any missing values exist, drop those rows (simple and safe approach)
    missing_before = df_clean.isnull().sum().sum()
    if missing_before > 0:
        print(f"\nFound {missing_before} missing values. Dropping rows with missing data...")
        df_clean = df_clean.dropna()
    else:
        print("\nNo missing values found. No action needed.")

    # ----- Remove duplicate records -----
    duplicates_before = df_clean.duplicated().sum()
    if duplicates_before > 0:
        print(f"Found {duplicates_before} duplicate rows. Removing them...")
        df_clean = df_clean.drop_duplicates().reset_index(drop=True)
    else:
        print("No duplicate rows found. No action needed.")

    print(f"Dataset shape after cleaning: {df_clean.shape}")
    return df_clean


def separate_features_and_target(df):
    """
    Separate input features (X) from the target variable (y).

    Target encoding:
    - good (low credit risk)  -> 0
    - bad  (high credit risk) -> 1

    We treat "bad" as the positive class because the bank cares most about
    correctly identifying high-risk applicants.

    Parameters
    ----------
    df : pandas.DataFrame
        Cleaned dataset.

    Returns
    -------
    X : pandas.DataFrame
        Feature columns.
    y : pandas.Series
        Encoded target labels (0 = good, 1 = bad).
    label_mapping : dict
        Mapping used for the target (needed for later decoding).
    """
    # X = all columns except the target
    X = df.drop(columns=["target"])

    # y = target column (good / bad)
    # Explicit mapping keeps good=0 and bad=1 (do not use LabelEncoder here,
    # because it sorts alphabetically and would assign bad=0, good=1).
    label_mapping = {"good": 0, "bad": 1}
    y = df["target"].map(label_mapping).astype(int)
    y.name = "target"

    print("\n--- Features (X) and Target (y) ---")
    print(f"Feature matrix shape: {X.shape}")
    print(f"Target vector shape: {y.shape}")
    print("Target encoding: good = 0 (low risk), bad = 1 (high risk)")
    print(f"Class counts:\n{y.value_counts().rename({0: 'good (0)', 1: 'bad (1)'})}")

    return X, y, label_mapping


def get_feature_column_types(X):
    """
    Identify numeric and categorical feature columns.

    Parameters
    ----------
    X : pandas.DataFrame
        Feature matrix.

    Returns
    -------
    numeric_cols : list
        Names of numeric columns.
    categorical_cols : list
        Names of categorical (object / string) columns.
    """
    numeric_cols = X.select_dtypes(include=["int64", "float64"]).columns.tolist()
    categorical_cols = X.select_dtypes(include=["object"]).columns.tolist()

    print("\n--- Column Types ---")
    print(f"Numeric columns ({len(numeric_cols)}): {numeric_cols}")
    print(f"Categorical columns ({len(categorical_cols)}): {categorical_cols}")

    return numeric_cols, categorical_cols


def build_preprocessor(numeric_cols, categorical_cols):
    """
    Build a preprocessing pipeline using ColumnTransformer.

    - Numeric features: StandardScaler (mean=0, std=1)
      Helps Logistic Regression train more stably.
    - Categorical features: OneHotEncoder
      Converts categories into binary columns without implying order.

    Parameters
    ----------
    numeric_cols : list
        Numeric column names.
    categorical_cols : list
        Categorical column names.

    Returns
    -------
    sklearn.compose.ColumnTransformer
        Preprocessor that transforms raw features into model-ready numbers.
    """
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_cols),
            (
                "cat",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                categorical_cols,
            ),
        ]
    )
    print("\nPreprocessor created: StandardScaler (numeric) + OneHotEncoder (categorical)")
    return preprocessor


def split_data(X, y, test_size=0.2, random_state=42):
    """
    Split the dataset into training (80%) and testing (20%) sets.

    stratify=y keeps the same good/bad ratio in both sets.
    This is important because the German Credit Dataset is imbalanced
    (more "good" than "bad" applicants).

    Parameters
    ----------
    X : pandas.DataFrame
        Features.
    y : pandas.Series
        Target labels.
    test_size : float
        Proportion of data used for testing (default 20%).
    random_state : int
        Random seed for reproducible results.

    Returns
    -------
    X_train, X_test, y_train, y_test
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=random_state,
        stratify=y,
    )

    print("\n--- Train / Test Split (80% / 20%) ---")
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Testing set:  {X_test.shape[0]} samples")
    print(f"Training class distribution:\n{y_train.value_counts().to_dict()}")
    print(f"Testing class distribution:\n{y_test.value_counts().to_dict()}")

    return X_train, X_test, y_train, y_test


def preprocess_pipeline(df):
    """
    Full preprocessing pipeline used by the main script.

    Returns
    -------
    dict
        Dictionary containing cleaned data splits, preprocessor,
        column lists, and the target label encoder.
    """
    # Step 2a: Clean the data
    df_clean = clean_data(df)

    # Step 2b: Separate X and y
    X, y, label_mapping = separate_features_and_target(df_clean)

    # Step 2c: Identify column types
    numeric_cols, categorical_cols = get_feature_column_types(X)

    # Step 2d: Build preprocessor (fit later on training data only)
    preprocessor = build_preprocessor(numeric_cols, categorical_cols)

    # Step 2e: Split into train and test sets
    X_train, X_test, y_train, y_test = split_data(X, y)

    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "preprocessor": preprocessor,
        "numeric_cols": numeric_cols,
        "categorical_cols": categorical_cols,
        "label_mapping": label_mapping,
        "feature_names_raw": X.columns.tolist(),
    }
