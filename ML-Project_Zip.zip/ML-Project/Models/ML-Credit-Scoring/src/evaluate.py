"""
STEP 4 & STEP 5 – Model Evaluation and Selection
------------------------------------------------
Evaluate each model using:
- Accuracy, Precision, Recall, F1-Score, ROC-AUC
- Confusion Matrix
- Classification Report

Then select the best-performing model for the Decision Support System.
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay,
)


def evaluate_model(model, X_test, y_test, model_name):
    """
    Evaluate a single trained model on the test set.

    Metrics follow Lecture #6 part 2 definitions:
    - Accuracy  = (TP + TN) / (TP + TN + FP + FN)
    - Precision = TP / (TP + FP)
    - Recall    = TP / (TP + FN)   [also called Sensitivity]
    - F1-Score  = harmonic mean of Precision and Recall
    - ROC-AUC   = area under the ROC curve (ranking quality)

    Positive class = 1 (bad / high credit risk)

    Returns
    -------
    dict
        Dictionary of evaluation metrics and predictions.
    """
    # Predicted class labels (0 or 1)
    y_pred = model.predict(X_test)

    # Predicted probabilities for the positive class (needed for ROC-AUC)
    y_prob = model.predict_proba(X_test)[:, 1]

    metrics = {
        "Model": model_name,
        "Accuracy": accuracy_score(y_test, y_pred),
        "Precision": precision_score(y_test, y_pred, zero_division=0),
        "Recall": recall_score(y_test, y_pred, zero_division=0),
        "F1-Score": f1_score(y_test, y_pred, zero_division=0),
        "ROC-AUC": roc_auc_score(y_test, y_prob),
        "y_pred": y_pred,
        "y_prob": y_prob,
        "confusion_matrix": confusion_matrix(y_test, y_pred),
        "classification_report": classification_report(
            y_test,
            y_pred,
            target_names=["good (low risk)", "bad (high risk)"],
            zero_division=0,
        ),
    }
    return metrics


def print_model_details(metrics):
    """Pretty-print confusion matrix and classification report for one model."""
    print(f"\n--- {metrics['Model']} ---")
    print("Confusion Matrix:")
    print(metrics["confusion_matrix"])
    print("\nClassification Report:")
    print(metrics["classification_report"])


def evaluate_all_models(models, X_test, y_test, results_dir):
    """
    Evaluate all models and build a comparison table.

    Parameters
    ----------
    models : dict
        Trained model pipelines.
    X_test, y_test :
        Held-out test data.
    results_dir : str
        Folder where plots and CSV results will be saved.

    Returns
    -------
    comparison_df : pandas.DataFrame
        Side-by-side metrics for all models.
    all_metrics : dict
        Full metric dictionaries keyed by model name.
    """
    print("\n" + "=" * 70)
    print("STEP 4: MODEL EVALUATION")
    print("=" * 70)

    os.makedirs(results_dir, exist_ok=True)
    all_metrics = {}
    rows = []

    for name, model in models.items():
        metrics = evaluate_model(model, X_test, y_test, name)
        all_metrics[name] = metrics
        print_model_details(metrics)

        rows.append(
            {
                "Model": name,
                "Accuracy": round(metrics["Accuracy"], 4),
                "Precision": round(metrics["Precision"], 4),
                "Recall": round(metrics["Recall"], 4),
                "F1-Score": round(metrics["F1-Score"], 4),
                "ROC-AUC": round(metrics["ROC-AUC"], 4),
            }
        )

        # Save confusion matrix plot for each model
        fig, ax = plt.subplots(figsize=(5, 4))
        disp = ConfusionMatrixDisplay(
            confusion_matrix=metrics["confusion_matrix"],
            display_labels=["Good", "Bad"],
        )
        disp.plot(ax=ax, cmap="Blues", colorbar=False)
        ax.set_title(f"Confusion Matrix – {name}")
        safe_name = name.lower().replace(" ", "_")
        fig.tight_layout()
        fig.savefig(os.path.join(results_dir, f"confusion_matrix_{safe_name}.png"), dpi=150)
        plt.close(fig)

    # ----- Comparison table -----
    comparison_df = pd.DataFrame(rows)
    print("\n" + "-" * 70)
    print("MODEL COMPARISON TABLE")
    print("-" * 70)
    print(comparison_df.to_string(index=False))

    # Save comparison table to CSV for the project report
    comparison_path = os.path.join(results_dir, "model_comparison.csv")
    comparison_df.to_csv(comparison_path, index=False)
    print(f"\nComparison table saved to: {comparison_path}")

    return comparison_df, all_metrics


def select_best_model(comparison_df, models):
    """
    STEP 5 – Select the best-performing model.

    Selection rule (suitable for credit risk Decision Support):
    1. Prefer the highest ROC-AUC (overall ranking of risk scores).
    2. If tied, prefer the highest F1-Score (balance of Precision & Recall).

    ROC-AUC is preferred because loan officers need a reliable risk ranking,
    not only a hard yes/no label.

    Returns
    -------
    best_name : str
        Name of the selected model.
    best_model : Pipeline
        The selected trained pipeline.
    explanation : str
        Short explanation for the report / README.
    """
    print("\n" + "=" * 70)
    print("STEP 5: MODEL SELECTION")
    print("=" * 70)

    # Sort by ROC-AUC first, then F1-Score
    ranked = comparison_df.sort_values(
        by=["ROC-AUC", "F1-Score"], ascending=False
    ).reset_index(drop=True)

    best_name = ranked.loc[0, "Model"]
    best_model = models[best_name]
    best_row = ranked.loc[0]

    explanation = (
        f"Selected model: {best_name}. "
        f"It achieved the best overall performance with "
        f"ROC-AUC = {best_row['ROC-AUC']}, "
        f"F1-Score = {best_row['F1-Score']}, "
        f"Accuracy = {best_row['Accuracy']}, "
        f"Precision = {best_row['Precision']}, "
        f"and Recall = {best_row['Recall']}. "
        f"ROC-AUC was used as the primary selection metric because it measures "
        f"how well the model ranks applicants by credit risk, which is useful "
        f"for a Decision Support System. The F1-Score was used as a secondary "
        f"metric to balance Precision and Recall when identifying high-risk (bad) applicants."
    )

    print(f"\nBest model: {best_name}")
    print(explanation)
    print(
        "\nReminder: This prediction is only a recommendation. "
        "The final loan decision always belongs to the loan officer."
    )

    return best_name, best_model, explanation
