"""
STEP 1 – Load and Understand the Dataset
----------------------------------------
This module loads the German Credit Dataset and prints a clear
overview so we understand the data before preprocessing.
"""

import os
import pandas as pd


def get_dataset_path():
    """
    Return the path to the German Credit Dataset CSV file.

    The dataset is stored in the project's dataset/ folder.
    """
    # Build a path relative to this file so the script works from any working directory
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dataset_path = os.path.join(project_root, "dataset", "german_credit_data.csv")
    return dataset_path


def load_dataset(filepath=None):
    """
    Load the German Credit Dataset into a pandas DataFrame.

    Parameters
    ----------
    filepath : str, optional
        Path to the CSV file. If None, the default project dataset path is used.

    Returns
    -------
    pandas.DataFrame
        The loaded credit dataset.
    """
    if filepath is None:
        filepath = get_dataset_path()

    # Read the CSV file into a DataFrame
    df = pd.read_csv(filepath)
    print(f"Dataset loaded successfully from: {filepath}")
    return df


def explore_dataset(df):
    """
    Display basic information about the dataset.

    Shows:
    - First five rows
    - Dataset shape
    - Data types
    - Missing values
    - Duplicate values
    - Summary statistics
    """
    print("\n" + "=" * 70)
    print("STEP 1: LOAD AND UNDERSTAND THE DATASET")
    print("=" * 70)

    # ----- First five rows -----
    # Helps us quickly see what the data looks like
    print("\n--- First Five Rows ---")
    print(df.head())

    # ----- Dataset shape -----
    # shape[0] = number of rows (loan applicants)
    # shape[1] = number of columns (features + target)
    print("\n--- Dataset Shape ---")
    print(f"Number of rows (applicants): {df.shape[0]}")
    print(f"Number of columns (features + target): {df.shape[1]}")

    # ----- Data types -----
    # Useful to identify which columns are numeric and which are categorical
    print("\n--- Data Types ---")
    print(df.dtypes)

    # ----- Missing values -----
    # Machine learning models cannot handle missing values directly
    print("\n--- Missing Values ---")
    missing = df.isnull().sum()
    print(missing)
    print(f"\nTotal missing values: {missing.sum()}")

    # ----- Duplicate values -----
    # Duplicate rows can bias the model if the same applicant appears more than once
    print("\n--- Duplicate Values ---")
    duplicate_count = df.duplicated().sum()
    print(f"Number of duplicate rows: {duplicate_count}")

    # ----- Summary statistics -----
    # Describes numeric columns (mean, std, min, max, etc.)
    print("\n--- Summary Statistics (Numeric Columns) ---")
    print(df.describe())

    # Also show value counts for the target column
    # Target: "good" = low credit risk, "bad" = high credit risk
    print("\n--- Target Variable Distribution ---")
    print(df["target"].value_counts())
    print("\nNote: 'good' = low credit risk | 'bad' = high credit risk")
    print("The model only recommends risk level; the loan officer makes the final decision.")


if __name__ == "__main__":
    # Allow this file to be run on its own for quick data exploration
    data = load_dataset()
    explore_dataset(data)
