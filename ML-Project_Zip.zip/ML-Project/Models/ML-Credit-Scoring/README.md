# ML-Based Credit Scoring System for Banking Loan Evaluation

## Phase 1 – Machine Learning Model Only

This repository contains the **Machine Learning phase** of the final-year Software Engineering project:

**ML-Based Credit Scoring System for Banking Loan Evaluation**

The goal of this phase is to train, evaluate, select, and save a credit risk prediction model using the **German Credit Dataset**.

> **Important:** This system is a **Decision Support System**.  
> Model predictions are **recommendations only**. They must **never** automatically approve or reject a loan. The final lending decision always belongs to the loan officer.

The web application (React.js, Flask API, MongoDB) will be developed in later phases. This folder contains **no frontend, backend API, or database code**.

---

## Project Structure

```text
ML-Credit-Scoring/
├── dataset/
│   └── german_credit_data.csv
├── models/
│   ├── best_credit_model.joblib
│   ├── label_mapping.joblib
│   └── model_metadata.json
├── src/
│   ├── load_data.py
│   ├── preprocess.py
│   ├── train_models.py
│   ├── evaluate.py
│   ├── feature_importance.py
│   └── main.py
├── results/
│   ├── model_comparison.csv
│   ├── feature_importance.csv
│   ├── feature_importance.png
│   └── confusion_matrix_*.png
├── requirements.txt
└── README.md
```

---

## Technologies

- Python
- Pandas
- NumPy
- Scikit-learn
- XGBoost
- Matplotlib
- Joblib

---

## Models Compared

Only these three algorithms are implemented:

1. **Logistic Regression** – probability-based linear classifier (sigmoid)
2. **Random Forest** – ensemble of decision trees with majority voting
3. **XGBoost** – gradient-boosted decision trees

---

## Dataset

- **Name:** German Credit Dataset
- **File:** `dataset/german_credit_data.csv`
- **Samples:** 1000 loan applicants
- **Target:**
  - `good` → low credit risk (encoded as `0`)
  - `bad` → high credit risk (encoded as `1`)

Positive class for evaluation metrics = **bad (high risk)**.

---

## Pipeline Steps

| Step | Description |
|------|-------------|
| 1 | Load and understand the dataset |
| 2 | Preprocess (clean, encode, split 80/20) |
| 3 | Train Logistic Regression, Random Forest, XGBoost |
| 4 | Evaluate with Accuracy, Precision, Recall, F1, ROC-AUC, Confusion Matrix |
| 5 | Select the best model |
| 6 | Analyse feature importance |
| 7 | Save model + preprocessing objects with Joblib |

---

## Setup and Run

### 1. Create / activate a Python environment (recommended)

```bash
# Example with conda
conda create -n credit-scoring python=3.11 -y
conda activate credit-scoring
```

### 2. Install dependencies

From the `ML-Credit-Scoring` folder:

```bash
pip install -r requirements.txt
```

### 3. Run the full ML pipeline

```bash
cd src
python main.py
```

After a successful run you should see:

- Trained model comparison in the terminal
- Plots and CSV files in `results/`
- Saved model artefacts in `models/`

---

## Saved Artefacts (for later web integration)

| File | Purpose |
|------|---------|
| `models/best_credit_model.joblib` | Full pipeline (preprocessing + best classifier) |
| `models/label_mapping.joblib` | Converts between `good`/`bad` and `0`/`1` |
| `models/model_metadata.json` | Model name and Decision Support notes |

Example of loading the model later (Flask phase):

```python
import joblib

model = joblib.load("models/best_credit_model.joblib")
labels = joblib.load("models/label_mapping.joblib")

# prediction = model.predict(applicant_dataframe)
# risk_label = labels["inverse_mapping"][int(prediction[0])]  # "good" or "bad"
```

---

## Academic Notes

This implementation follows classification concepts taught in the module lectures:

- Logistic Regression and evaluation metrics (Accuracy, Precision, Recall, F1)
- Decision Trees / Random Forest ensembles
- Train/test split for model evaluation

The selected model is chosen primarily by **ROC-AUC**, with **F1-Score** as a secondary metric, because ranking applicants by risk is useful for loan officers.

---

## Next Phases (Out of Scope Here)

- React.js frontend for loan officers
- Flask API to serve the saved model
- MongoDB for applicant / decision storage
