import { Link, useLocation, Navigate } from 'react-router-dom';

export default function ResultPage() {
  const location = useLocation();
  const prediction = location.state?.prediction;
  const record = location.state?.record;

  if (!prediction) {
    return <Navigate to="/evaluate" replace />;
  }

  const isGood = prediction.prediction_class === 1;
  const confidencePct = Math.round((prediction.confidence || 0) * 100);
  const goodPct = Math.round((prediction.probabilities?.good_credit_risk || 0) * 100);
  const badPct = Math.round((prediction.probabilities?.bad_credit_risk || 0) * 100);

  return (
    <div className="page result-page">
      <header className="page-hero">
        <div>
          <p className="eyebrow">Model output</p>
          <h1>Recommendation ready</h1>
          <p className="lede narrow">
            This result is decision support only. A loan officer makes the final approval or rejection.
          </p>
        </div>
      </header>

      <section className={`result-banner ${isGood ? 'is-good' : 'is-bad'}`}>
        <div className="result-banner-copy">
          <p className="result-kicker">Random Forest prediction</p>
          <h2>{prediction.prediction_label}</h2>
          <p>{prediction.recommendation_note}</p>
        </div>
        <div className="result-meter" aria-label={`Confidence ${confidencePct} percent`}>
          <svg viewBox="0 0 120 120" className="meter-ring">
            <circle cx="60" cy="60" r="52" className="meter-track" />
            <circle
              cx="60"
              cy="60"
              r="52"
              className="meter-value"
              style={{
                strokeDasharray: `${(confidencePct / 100) * 327} 327`,
              }}
            />
          </svg>
          <div className="meter-label">
            <strong>{confidencePct}%</strong>
            <span>confidence</span>
          </div>
        </div>
      </section>

      <section className="result-split">
        <article className="stat-block">
          <h3>Probability split</h3>
          <div className="prob-bars">
            <div>
              <div className="prob-row">
                <span>Good credit risk</span>
                <span>{goodPct}%</span>
              </div>
              <div className="bar">
                <span className="bar-good" style={{ width: `${goodPct}%` }} />
              </div>
            </div>
            <div>
              <div className="prob-row">
                <span>Bad credit risk</span>
                <span>{badPct}%</span>
              </div>
              <div className="bar">
                <span className="bar-bad" style={{ width: `${badPct}%` }} />
              </div>
            </div>
          </div>
        </article>

        <article className="stat-block">
          <h3>Record details</h3>
          <dl className="detail-list">
            <div>
              <dt>Model</dt>
              <dd>{prediction.model_name}</dd>
            </div>
            <div>
              <dt>Class code</dt>
              <dd>{prediction.prediction_class}</dd>
            </div>
            <div>
              <dt>History id</dt>
              <dd className="mono">{record?.id || '—'}</dd>
            </div>
            <div>
              <dt>Saved at</dt>
              <dd>
                {record?.created_at
                  ? new Date(record.created_at).toLocaleString()
                  : '—'}
              </dd>
            </div>
          </dl>
        </article>
      </section>

      <div className="form-actions end">
        <Link to="/evaluate" className="btn btn-ghost">
          Score another applicant
        </Link>
        <Link to="/history" className="btn btn-primary">
          View prediction history
        </Link>
      </div>
    </div>
  );
}
