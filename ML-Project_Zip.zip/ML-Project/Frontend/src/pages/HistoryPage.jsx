import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import { displayApplicantKey, displayApplicantValue } from '../data/formFields';

export default function HistoryPage() {
  const [history, setHistory] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [deletingId, setDeletingId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const result = await api.getHistory();
      setHistory(result.data.history || []);
    } catch (err) {
      setError(err.message || 'Could not load history.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openDetail = async (id) => {
    try {
      const result = await api.getHistoryItem(id);
      setSelected(result.data.record);
    } catch (err) {
      setError(err.message || 'Could not load record.');
    }
  };

  const remove = async (id) => {
    const confirmed = window.confirm('Delete this prediction record?');
    if (!confirmed) return;
    setDeletingId(id);
    try {
      await api.deleteHistoryItem(id);
      setHistory((prev) => prev.filter((item) => item.id !== id));
      if (selected?.id === id) setSelected(null);
    } catch (err) {
      setError(err.message || 'Delete failed.');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="page history-page">
      <header className="page-hero">
        <div>
          <p className="eyebrow">Archive</p>
          <h1>Prediction history</h1>
          <p className="lede narrow">
            Review prior Random Forest recommendations stored in MongoDB, newest first.
          </p>
        </div>
        <Link to="/evaluate" className="btn btn-primary">
          New evaluation
        </Link>
      </header>

      {error ? <p className="form-alert">{error}</p> : null}

      {loading ? (
        <p className="empty-state">Loading history…</p>
      ) : history.length === 0 ? (
        <div className="empty-panel">
          <h2>No predictions yet</h2>
          <p>Run an evaluation to populate this archive.</p>
          <Link to="/evaluate" className="btn btn-primary">
            Start scoring
          </Link>
        </div>
      ) : (
        <div className="history-layout">
          <ul className="history-list">
            {history.map((item) => {
              const isGood = item.prediction_class === 1;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    className={`history-row ${selected?.id === item.id ? 'active' : ''}`}
                    onClick={() => openDetail(item.id)}
                  >
                    <span className={`chip ${isGood ? 'chip-good' : 'chip-bad'}`}>
                      {item.prediction_label}
                    </span>
                    <span className="history-main">
                      <strong>
                        Amount {item.applicant?.["credit_amount'(000)"] ?? item.applicant?.credit_amount ?? '—'}
                      </strong>
                      <small>
                        {item.applicant?.Loan_purpose || '—'} · {item.applicant?.age ?? '—'} yrs
                      </small>
                    </span>
                    <span className="history-meta">
                      <strong>{Math.round((item.confidence || 0) * 100)}%</strong>
                      <small>
                        {item.created_at
                          ? new Date(item.created_at).toLocaleString()
                          : '—'}
                      </small>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>

          <aside className="history-detail">
            {selected ? (
              <>
                <div className="detail-head">
                  <div>
                    <p className="eyebrow">Selected record</p>
                    <h2>{selected.prediction_label}</h2>
                  </div>
                  <button
                    type="button"
                    className="btn btn-danger"
                    disabled={deletingId === selected.id}
                    onClick={() => remove(selected.id)}
                  >
                    {deletingId === selected.id ? 'Deleting…' : 'Delete'}
                  </button>
                </div>

                <dl className="detail-list">
                  <div>
                    <dt>Confidence</dt>
                    <dd>{Math.round((selected.confidence || 0) * 100)}%</dd>
                  </div>
                  <div>
                    <dt>Model</dt>
                    <dd>{selected.model_name}</dd>
                  </div>
                  <div>
                    <dt>Created by</dt>
                    <dd>{selected.created_by || '—'}</dd>
                  </div>
                  <div>
                    <dt>Timestamp</dt>
                    <dd>
                      {selected.created_at
                        ? new Date(selected.created_at).toLocaleString()
                        : '—'}
                    </dd>
                  </div>
                </dl>

                <h3 className="detail-sub">Applicant snapshot</h3>
                <div className="applicant-grid">
                  {Object.entries(selected.applicant || {}).map(([key, value]) => (
                    <div key={key}>
                      <span>{displayApplicantKey(key)}</span>
                      <strong>{String(displayApplicantValue(key, value))}</strong>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="empty-panel compact">
                <h2>Select a record</h2>
                <p>Choose a prediction from the list to inspect full applicant details.</p>
              </div>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
