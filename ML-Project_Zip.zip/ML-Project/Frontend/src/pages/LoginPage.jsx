import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiReady, setApiReady] = useState(null);

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/evaluate', { replace: true });
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    let alive = true;
    api
      .health()
      .then(() => alive && setApiReady(true))
      .catch(() => alive && setApiReady(false));
    return () => {
      alive = false;
    };
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = await api.login(username.trim(), password);
      login(result.data.user);
      navigate('/evaluate');
    } catch (err) {
      setError(err.message || 'Unable to sign in.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-visual" aria-hidden="true">
        <img
          src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1800&q=80"
          alt=""
        />
        <div className="login-visual-veil" />
        <div className="login-visual-copy">
          <p className="eyebrow">Banking decision support</p>
          <h1 className="display">Clarity before every lending decision.</h1>
          <p className="lede">
            Random Forest scoring with transparent confidence — a recommendation for loan officers, never an automatic verdict.
          </p>
        </div>
      </div>

      <section className="login-panel">
        <div className="login-panel-inner">
          <header className="login-brand">
            <span className="brand-mark large" aria-hidden="true" />
            <div>
              <p className="brand-name">Lanka Trust Bank</p>
              <p className="brand-tag">ML-based loan evaluation</p>
            </div>
          </header>

          <h2 className="login-heading">Sign in to the evaluation desk</h2>
          <p className="login-sub">
            Use your officer credentials to assess applicants and review prior scores.
          </p>

          <form className="login-form" onSubmit={handleSubmit}>
            <label className="field" htmlFor="username">
              <span className="field-label">Username</span>
              <input
                id="username"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </label>
            <label className="field" htmlFor="password">
              <span className="field-label">Password</span>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </label>

            {error ? <p className="form-alert">{error}</p> : null}

            <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
              {loading ? 'Signing in…' : 'Enter workspace'}
            </button>
          </form>

          <div className="login-meta">
            <p>
              API status:{' '}
              <span className={apiReady ? 'status-ok' : apiReady === false ? 'status-bad' : 'status-wait'}>
                {apiReady === null ? 'Checking…' : apiReady ? 'Connected' : 'Offline — start Flask backend'}
              </span>
            </p>
            <Link className="text-link" to="/evaluate">
              Continue if already signed in
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
