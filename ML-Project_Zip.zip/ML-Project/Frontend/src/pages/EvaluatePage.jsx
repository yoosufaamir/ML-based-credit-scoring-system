import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Field from '../components/Field';
import OptionGuide from '../components/OptionGuide';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import {
  EMPTY_FORM,
  FIELD_GROUPS,
  FORM_STEPS,
  toPayload,
  validateStep,
} from '../data/formFields';

export default function EvaluatePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stepIndex, setStepIndex] = useState(0);
  const [values, setValues] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState('');
  const [loading, setLoading] = useState(false);

  const step = FORM_STEPS[stepIndex];
  const fields = FIELD_GROUPS[step.id];
  const progress = ((stepIndex + 1) / FORM_STEPS.length) * 100;

  const filledCount = useMemo(() => {
    return Object.values(values).filter((v) => v !== '' && v != null).length;
  }, [values]);

  const onChange = (name, value) => {
    setValues((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => {
      if (!prev[name]) return prev;
      const next = { ...prev };
      delete next[name];
      return next;
    });
  };

  const goNext = () => {
    const stepErrors = validateStep(step.id, values);
    setErrors(stepErrors);
    if (Object.keys(stepErrors).length) return;
    setStepIndex((i) => Math.min(i + 1, FORM_STEPS.length - 1));
  };

  const goBack = () => {
    setErrors({});
    setStepIndex((i) => Math.max(i - 1, 0));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const stepErrors = validateStep(step.id, values);
    setErrors(stepErrors);
    if (Object.keys(stepErrors).length) return;

    setLoading(true);
    setSubmitError('');
    try {
      const payload = toPayload(values, user?.username);
      const result = await api.predict(payload);
      navigate('/result', {
        state: {
          prediction: result.data.prediction,
          record: result.data.record,
        },
      });
    } catch (err) {
      const detail = err.errors?.length
        ? err.errors.join(' ')
        : err.message || 'Prediction failed.';
      setSubmitError(detail);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page evaluate-page">
      <header className="page-hero">
        <div>
          <p className="eyebrow">New evaluation</p>
          <h1>Score an applicant</h1>
          <p className="lede narrow">
            Capture the lending profile in three short stages. The Random Forest model returns a risk label and confidence for officer review.
          </p>
        </div>
        <aside className="hero-aside">
          <p className="aside-label">Form progress</p>
          <p className="aside-value">{filledCount}/20 fields</p>
          <div className="progress-track" aria-hidden="true">
            <span style={{ width: `${progress}%` }} />
          </div>
          <p className="aside-note">Step {stepIndex + 1} of {FORM_STEPS.length}</p>
        </aside>
      </header>

      <ol className="stepper" aria-label="Evaluation steps">
        {FORM_STEPS.map((item, index) => (
          <li
            key={item.id}
            className={
              index === stepIndex
                ? 'stepper-item active'
                : index < stepIndex
                  ? 'stepper-item done'
                  : 'stepper-item'
            }
          >
            <span className="stepper-index">{index + 1}</span>
            <span>
              <strong>{item.title}</strong>
              <small>{item.subtitle}</small>
            </span>
          </li>
        ))}
      </ol>

      <form className="evaluate-form" onSubmit={handleSubmit}>
        <div className="form-panel">
          <div className="form-panel-head">
            <h2>{step.title}</h2>
            <p>{step.subtitle}</p>
          </div>

          <div className="form-grid">
            {fields.map((field) => (
              <Field
                key={field.name}
                field={field}
                value={values[field.name]}
                error={errors[field.name]}
                onChange={onChange}
              />
            ))}
          </div>

          {step.id === 'accounts' ? (
            <div className="option-guide-stack">
              {fields
                .filter((field) => field.optionGuide)
                .map((field) => {
                  const options = (field.options || []).map((opt) =>
                    typeof opt === 'string' ? { value: opt, label: opt } : opt,
                  );
                  const selected = options.find(
                    (opt) => opt.value === values[field.name],
                  );
                  return (
                    <OptionGuide
                      key={field.name}
                      title={field.label}
                      items={field.optionGuide}
                      activeLabel={selected?.label}
                    />
                  );
                })}
            </div>
          ) : null}

          {submitError ? <p className="form-alert">{submitError}</p> : null}

          <div className="form-actions">
            <button
              type="button"
              className="btn btn-ghost"
              onClick={goBack}
              disabled={stepIndex === 0 || loading}
            >
              Back
            </button>
            {stepIndex < FORM_STEPS.length - 1 ? (
              <button type="button" className="btn btn-primary" onClick={goNext}>
                Continue
              </button>
            ) : (
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Scoring…' : 'Generate credit score'}
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}
