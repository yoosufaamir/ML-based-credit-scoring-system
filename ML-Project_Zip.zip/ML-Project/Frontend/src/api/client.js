const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:5000/api';

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  });

  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok) {
    const error = new Error(payload?.message || 'Request failed.');
    error.status = response.status;
    error.errors = payload?.errors || [];
    error.payload = payload;
    throw error;
  }

  return payload;
}

export const api = {
  health: () => request('/health'),
  login: (username, password) =>
    request('/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),
  predict: (applicant) =>
    request('/predict', {
      method: 'POST',
      body: JSON.stringify(applicant),
    }),
  getHistory: () => request('/history'),
  getHistoryItem: (id) => request(`/history/${id}`),
  deleteHistoryItem: (id) =>
    request(`/history/${id}`, { method: 'DELETE' }),
};

export { API_BASE };
