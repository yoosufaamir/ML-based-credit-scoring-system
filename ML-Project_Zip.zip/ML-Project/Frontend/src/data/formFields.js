/** Form field definitions matching the backend training schema */

export const FORM_STEPS = [
  {
    id: 'profile',
    title: 'Applicant profile',
    subtitle: 'Identity, employment, and housing context',
  },
  {
    id: 'accounts',
    title: 'Accounts & history',
    subtitle: 'Checking, savings, and past credit behaviour',
  },
  {
    id: 'loan',
    title: 'Loan request',
    subtitle: 'Amount, purpose, duration, and collateral',
  },
];

export const FIELD_GROUPS = {
  profile: [
    {
      name: 'age',
      label: 'Age',
      type: 'number',
      min: 18,
      placeholder: 'e.g. 35',
    },
    {
      name: 'status_and_sex',
      label: 'Personal status & sex',
      type: 'select',
      options: [
        'female : divorced/separated/married',
        'male : divorced/separated',
        'male : married/widowed',
        'male : single',
      ],
    },
    {
      name: 'job',
      label: 'Job category',
      type: 'select',
      options: [
        'management/ self-employed/highly qualified employee',
        'skilled employee/ official',
        'unemployed/ unskilled - non-resident',
        'unskilled - resident',
      ],
    },
    {
      name: 'employment_since',
      label: 'Employment duration',
      type: 'select',
      options: [
        '1 to < 4 years',
        '4 to < 7 years',
        '< 1 year',
        '>= 7 years',
        'unemployed',
      ],
    },
    {
      name: 'Housing_ownership',
      label: 'Housing',
      type: 'select',
      options: ['for free', 'own', 'rent'],
    },
    {
      name: 'residence_since',
      label: 'Years at current residence',
      type: 'number',
      min: 1,
      placeholder: 'e.g. 2',
    },
    {
      name: 'telephone',
      label: 'Telephone on file',
      type: 'select',
      options: ['none', 'yes, registered under the customers name'],
    },
    {
      name: 'work_eligibility_status',
      label: 'Foreign worker status',
      type: 'select',
      options: [
        { value: 'yes', label: 'Yes (foreign worker)' },
        { value: 'no', label: 'No' },
      ],
    },
  ],
  accounts: [
    {
      name: 'status_account',
      label: 'Current account status',
      type: 'select',
      // value = original German Credit categories (required by the ML model)
      // label = LKR banking-friendly text shown in the UI
      options: [
        { value: '< 0 DM', label: 'Overdraft (Below LKR 0)' },
        { value: '0 to < 200 DM', label: 'LKR 0 – LKR 100,000 (Low Balance)' },
        {
          value: '>= 200 DM',
          label: 'Above LKR 500,000 (High Balance)',
        },
        {
          value: 'no checking account',
          label: 'No Current Account',
        },
      ],
      optionGuide: [
        {
          label: 'Overdraft (Below LKR 0)',
          description: 'Negative current-account balance.',
        },
        {
          label: 'LKR 0 – LKR 100,000 (Low Balance)',
          description: 'Limited funds in the current account.',
        },
        {
          label: 'Above LKR 500,000 (High Balance)',
          description: 'Strong positive current-account balance.',
        },
        {
          label: 'No Current Account',
          description: 'No current/checking account on file.',
        },
      ],
    },
    {
      name: 'status_savings',
      label: 'Savings account',
      type: 'select',
      // value = original German Credit categories (required by the ML model)
      options: [
        {
          value: '< 100 DM',
          label: 'LKR 0 – LKR 100,000 (Low Balance)',
        },
        {
          value: '100 to < 500 DM',
          label: 'LKR 100,001 – LKR 500,000 (Moderate Balance)',
        },
        {
          value: '500 to < 1000 DM',
          label: 'Above LKR 500,000 (High Balance)',
        },
        {
          value: '>= 1000 DM',
          label: 'Above LKR 500,000 (High Balance)',
        },
        {
          value: 'unknown/ no savings account',
          label: 'No Savings Account',
        },
      ],
      optionGuide: [
        {
          label: 'LKR 0 – LKR 100,000 (Low Balance)',
          description: 'Low savings balance (up to LKR 100,000).',
        },
        {
          label: 'LKR 100,001 – LKR 500,000 (Moderate Balance)',
          description: 'Moderate savings (LKR 100,001–500,000).',
        },
        {
          label: 'Above LKR 500,000 (High Balance)',
          description: 'High savings balance (above LKR 500,000).',
        },
        {
          label: 'No Savings Account',
          description: 'No savings account, or status unknown.',
        },
      ],
    },
    {
      name: 'credit_history',
      label: 'Credit history',
      type: 'select',
      options: [
        'all credits at this bank paid back duly',
        'critical account/ other credits existing (not at this bank)',
        'delay in paying off in the past',
        'existing credits paid back duly till now',
        'no credits taken/ all credits paid back duly',
      ],
    },
    {
      name: 'n_credits',
      label: 'Existing credits at this bank',
      type: 'number',
      min: 1,
      placeholder: 'e.g. 1',
    },
    {
      name: 'other_installment_plans',
      label: 'Other installment plans',
      type: 'select',
      options: ['bank', 'none', 'stores'],
    },
    {
      name: 'payment_to_income_ratio',
      label: 'Installment rate (% of disposable income)',
      type: 'number',
      min: 1,
      max: 4,
      placeholder: '1–4',
    },
  ],
  loan: [
    {
      name: 'credit_amount',
      label: 'Loan amount',
      type: 'number',
      min: 1,
      placeholder: 'e.g. 2500',
    },
    {
      name: 'Loan_duration',
      label: 'Loan duration (months)',
      type: 'number',
      min: 1,
      placeholder: 'e.g. 12',
    },
    {
      name: 'Loan_purpose',
      label: 'Loan purpose',
      type: 'select',
      options: [
        'business',
        'car (new)',
        'car (used)',
        'domestic appliances',
        'education',
        'furniture/equipment',
        'others',
        'radio/television',
        'repairs',
        'retraining',
      ],
    },
    {
      name: 'collateral',
      label: 'Collateral / property',
      type: 'select',
      options: [
        'car',
        'none',
        'real estate',
        'savings agreement/life insurance',
      ],
    },
    {
      name: 'secondary_obligor',
      label: 'Other debtors / guarantors',
      type: 'select',
      options: ['co-applicant', 'guarantor', 'none'],
    },
    {
      name: 'n_guarantors',
      label: 'Number of people liable',
      type: 'number',
      min: 1,
      placeholder: 'e.g. 1',
    },
  ],
};

export const EMPTY_FORM = {
  age: '',
  status_and_sex: '',
  job: '',
  employment_since: '',
  Housing_ownership: '',
  residence_since: '',
  telephone: '',
  work_eligibility_status: '',
  status_account: '',
  status_savings: '',
  credit_history: '',
  n_credits: '',
  other_installment_plans: '',
  payment_to_income_ratio: '',
  credit_amount: '',
  Loan_duration: '',
  Loan_purpose: '',
  collateral: '',
  secondary_obligor: '',
  n_guarantors: '',
};

export function validateStep(stepId, values) {
  const fields = FIELD_GROUPS[stepId] || [];
  const errors = {};

  fields.forEach((field) => {
    const raw = values[field.name];
    if (raw === '' || raw === null || raw === undefined) {
      errors[field.name] = 'Required';
      return;
    }
    if (field.type === 'number') {
      const num = Number(raw);
      if (Number.isNaN(num)) {
        errors[field.name] = 'Enter a number';
        return;
      }
      if (field.min != null && num < field.min) {
        errors[field.name] = `Must be ≥ ${field.min}`;
      }
      if (field.max != null && num > field.max) {
        errors[field.name] = `Must be ≤ ${field.max}`;
      }
    }
  });

  return errors;
}

export function toPayload(values, username) {
  const payload = { ...values, created_by: username };
  [
    'age',
    'residence_since',
    'n_credits',
    'payment_to_income_ratio',
    'credit_amount',
    'Loan_duration',
    'n_guarantors',
  ].forEach((key) => {
    if (payload[key] !== '' && payload[key] != null) {
      payload[key] = Number(payload[key]);
    }
  });
  return payload;
}

/** Friendly labels for values still stored in original training form */
export const STATUS_ACCOUNT_LABELS = {
  '< 0 DM': 'Overdraft (Below LKR 0)',
  '0 to < 200 DM': 'LKR 0 – LKR 100,000 (Low Balance)',
  '>= 200 DM': 'Above LKR 500,000 (High Balance)',
  'no checking account': 'No Current Account',
};

export const STATUS_SAVINGS_LABELS = {
  '< 100 DM': 'LKR 0 – LKR 100,000 (Low Balance)',
  '100 to < 500 DM': 'LKR 100,001 – LKR 500,000 (Moderate Balance)',
  '500 to < 1000 DM': 'Above LKR 500,000 (High Balance)',
  '>= 1000 DM': 'Above LKR 500,000 (High Balance)',
  'unknown/ no savings account': 'No Savings Account',
};

export function displayApplicantKey(key) {
  if (key === "credit_amount'(000)") return 'credit_amount';
  if (key === 'status_account') return 'Current account status';
  if (key === 'status_savings') return 'Savings account';
  return key;
}

export function displayApplicantValue(key, value) {
  if (key === 'status_account') {
    return STATUS_ACCOUNT_LABELS[value] || value;
  }
  if (key === 'status_savings') {
    return STATUS_SAVINGS_LABELS[value] || value;
  }
  return value;
}
