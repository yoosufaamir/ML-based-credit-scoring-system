export default function Field({
  field,
  value,
  error,
  onChange,
}) {
  const id = `field-${field.name}`;
  const options = (field.options || []).map((opt) =>
    typeof opt === 'string' ? { value: opt, label: opt } : opt,
  );

  return (
    <div className={`field-wrap ${error ? 'has-error' : ''}`}>
      <label className="field" htmlFor={id}>
        <span className="field-label">{field.label}</span>
        {field.type === 'select' ? (
          <select
            id={id}
            name={field.name}
            value={value}
            onChange={(e) => onChange(field.name, e.target.value)}
          >
            <option value="">Select…</option>
            {options.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        ) : (
          <input
            id={id}
            name={field.name}
            type="number"
            min={field.min}
            max={field.max}
            placeholder={field.placeholder}
            value={value}
            onChange={(e) => onChange(field.name, e.target.value)}
          />
        )}
        {error ? <span className="field-error">{error}</span> : null}
      </label>
    </div>
  );
}
