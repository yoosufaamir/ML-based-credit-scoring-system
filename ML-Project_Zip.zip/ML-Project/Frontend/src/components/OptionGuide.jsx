export default function OptionGuide({ title, items, activeLabel }) {
  if (!items?.length) return null;

  return (
    <div className="option-guide" aria-label={title}>
      <p className="option-guide-title">{title}</p>
      <ul className="option-guide-list">
        {items.map((item) => (
          <li
            key={item.label}
            className={activeLabel === item.label ? 'is-active' : ''}
          >
            <strong>{item.label}</strong>
            <span>{item.description}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
