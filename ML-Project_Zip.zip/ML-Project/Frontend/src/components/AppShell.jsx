import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function AppShell({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  return (
    <div className="shell">
      <div className="shell-glow" aria-hidden="true" />
      <header className="shell-header">
        <div className="shell-brand">
          <span className="brand-mark" aria-hidden="true" />
          <div>
            <p className="brand-name">Lanka Trust Bank</p>
            <p className="brand-tag">Loan evaluation desk</p>
          </div>
        </div>

        <nav className="shell-nav" aria-label="Primary">
          <NavLink to="/evaluate" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            Evaluate
          </NavLink>
          <NavLink to="/history" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            History
          </NavLink>
        </nav>

        <div className="shell-user">
          <div className="user-meta">
            <span className="user-name">{user?.username}</span>
            <span className="user-role">{user?.role || 'officer'}</span>
          </div>
          <button type="button" className="btn btn-ghost" onClick={handleLogout}>
            Sign out
          </button>
        </div>
      </header>

      <main className="shell-main">{children}</main>
    </div>
  );
}
