# Lanka Trust Bank — Frontend

React UI for the **ML-Based Credit Scoring System for Banking Loan Evaluation**.

## Run

1. Start the Flask backend on port `5000`
2. From this folder:

```bash
npm install
npm run dev
```

Open the URL Vite prints (usually `http://127.0.0.1:5173`).

Demo login: `admin` / `admin123`

## Screens

- **Login** — branded entry with API health status
- **Evaluate** — 3-step applicant form → `POST /api/predict`
- **Result** — Good/Bad Credit Risk + confidence
- **History** — list, detail, delete from MongoDB

Optional env override (create `.env`):

```
VITE_API_BASE=http://127.0.0.1:5000/api
```
